<?php
return [
    'interfaces' => [
        'eth0',
        'eth1',
        'eth2',
    ],
];
