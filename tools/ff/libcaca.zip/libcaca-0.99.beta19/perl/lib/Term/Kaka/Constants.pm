package Term::Kaka::Constants;

use Term::Caca::Constants qw(:all);
push @ISA, 'Term::Caca::Constants';

*Term::Kaka::Constants::EXPORT_OK   = *Term::Caca::Constants::EXPORT_OK;
*Term::Kaka::Constants::EXPORT_TAGS = *Term::Caca::Constants::EXPORT_TAGS;

1;
