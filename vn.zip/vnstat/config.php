<?php
return [
    'interfaces' => [
        // You can list any number of interfaces here. The top interface is the default one. When no interface is
        // defined (or this config file was not copied to "config.php"), the default interface is used.
        'eth0',
        'eth1',
        'eth2',
    ],
];
